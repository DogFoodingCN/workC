// ==UserScript==
// @name         Boss直聘过滤
// @namespace    http://dogfooding.cn/
// @version      0.1
// @description  收集有用信息，过滤无用信息
// @author       AllenZhang
// @match        https://www.zhipin.com/web/geek/job?*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=zhipin.com
// @grant        none
// @require      http://libs.baidu.com/jquery/2.0.0/jquery.min.js
// ==/UserScript==

var pages = 1;
var intervalid;
(function() {
    'use strict';
    // wait page loaded
    intervalid = setInterval(filter,2000);
})();

var base_url = "https://www.zhipin.com";
var needs = ["php","go","后端", "前端"];
var blacklist = ["软通动力"];

function filter(){
    if (pages == 0) {
        clearInterval(intervalid);
        return;
    }
    pages--;
    var res = [];
    var list = $(".job-card-wrapper");
    for(let i = 0; i < list.length; i++) {
        let info = list.eq(i);
        //tags
        let base_tags =[], req_tags = [],comp_tags = [];
        info.find(".job-info .tag-list li").each(function(){
            base_tags.push($(this).text());
        })
        info.find(".job-card-footer .tag-list li").each(function(){
            req_tags.push($(this).text());
        });
        info.find(".company-tag-list li").each(function(){
            comp_tags.push($(this).text());
        });

        let job = {
            base:{
                name:info.find(".job-name").text(),
                area:info.find(".job-area").text(),
                salary:info.find(".salary").text(),
                tags:base_tags,
                link:base_url + info.find(".job-card-left").attr("href"),
            },
            requirement:{
                tags:req_tags,
            },
            company:{
                name:info.find(".company-name a").text(),
                desc:info.find(".info-desc").text(),
                tags:comp_tags,
                logo:info.find(".company-logo img").attr("src"),
                link:base_url + info.find(".company-name a").attr("href"),
            },
        }
        // 过滤非目标岗位
        if (job_fileter(job.base.name)) {
            console.log(job.base.name);
            info.hide();
            continue;
        }
        // 过滤公司
        if (company_fileter(job.company.name)) {
            console.log(job.company.name);
            info.hide();
            continue;
        }
        res.push(job);
    }
    save_data(res);
}

// 筛选职位关键字
function job_fileter(name) {
    for(let i=0; i < needs.length; i++) {
        var reg = new RegExp(needs[i],"i");
        if (name.search(reg) < 0) {
            continue;
        }
        return false;
    }
    return true;
}

// 过滤黑名单公司
function company_fileter(name) {
    for(let i=0; i < blacklist.length; i++) {
        var reg = new RegExp(blacklist[i],"i");
        if (name.search(reg) >= 0) {
            return true;
        }
    }
    return false;
}

// 保存数据
function save_data(data){
    $.ajax({
        type:"post",
        url:"http://localhost:8000/job/save",
        dataType: "json",
        contentType: "application/json",
        async:true,
        data:JSON.stringify(data),
        success:function(res) {
            console.log(res)
            $(".ui-icon-arrow-right").parents("a")[0].click()
        },
        error:function(res){console.log(res)},
    })
}